// Fill out your copyright notice in the Description page of Project Settings.

#include "HuntAndKillGen.h"


// Sets default values
AHuntAndKillGen::AHuntAndKillGen()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AHuntAndKillGen::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AHuntAndKillGen::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}


TArray<int32> AHuntAndKillGen::GenerateMaze(int32 x, int32 y, int32 xpad, int32 ypad)
{

	struct Cell {
		bool N, S, E, W, Visited;
		int32 x, y, index;
	};

	Cell proto;
	TArray<Cell> Maze;
	int size = x * y;
	Maze.Init(proto, size);



}

