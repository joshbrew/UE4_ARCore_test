// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HuntAndKillGen.generated.h"

UCLASS()
class HANDHELD_AR_API AHuntAndKillGen : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AHuntAndKillGen();

	UFUNCTION(BlueprintCallable, Category = "MazeGen")
		TArray<int32> GenerateMaze(int32 x, int32 y, int32 xpad, int32 ypad);




protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
};
